package com.fh.entity.weixin;

/** 菜单
 * @author FH
 * Q: 3 13596 79 0
 * 2016.11.1
 */
public class Menu {
	private ComplexButton[] button;

	public ComplexButton[] getButton() {
		return button;
	}

	public void setButton(ComplexButton[] button) {
		this.button = button;
	}
}
