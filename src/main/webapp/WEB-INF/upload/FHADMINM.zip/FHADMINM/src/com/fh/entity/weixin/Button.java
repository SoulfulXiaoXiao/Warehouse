package com.fh.entity.weixin;

/** 微信菜单的基类
 * @author FH
 * Q: 3 13596 79 0
 * 2016.11.1
 */
public class Button {
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}