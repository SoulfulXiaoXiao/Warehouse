open the app.variables.less to change the variables

http://localhost/app/css/less/less.php?app.less
use the compiled css to replace the css/app.css