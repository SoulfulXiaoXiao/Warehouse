'use strict';

/* Services */


// Demonstrate how to register services
angular.module('app.services', []);