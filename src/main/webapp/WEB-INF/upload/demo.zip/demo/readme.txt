1: Please put the files on a server or local host to preview. 
eg: put the files under a localhost "angulr" folder

looks like:
"angulr/css"
"angulr/fonts"
"angulr/img"
"angulr/js"
"angulr/tpl"
"angulr/l10n"
"angulr/index.html"

then preview:  http://localhost/angulr/index.html  in your browser.


2: Documents locate "tpl/docs.html" or "http://localhost/angulr/index.html#/app/docs"
online: http://flatfull.com/themes/angulr/#/app/docs